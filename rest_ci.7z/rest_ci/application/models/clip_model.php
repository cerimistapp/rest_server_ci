<?php


class clip_model extends CI_Model
{
    public function getClip($id = null)
    {
        if ($id === null) {

            return $this->db->get('clip')->result_array();
        } else {
            return $this->db->get_where('clip', ['id' => $id])->result_array();
        }
    }

    public function deleteClip($id)
    {
        $this->db->delete('clip', ['id' => $id]);
        return $this->db->affected_rows();
    }

    public function createClip($data)
    {
        # code...
        $this->db->insert('clip', $data);
        return $this->db->affected_rows();
    }

    public function updateClip($data, $id)
    {
        # code...

        $this->db->update('clip',$data, ['id' => $id]);
        return $this->db->affected_rows();

    }
    
}
