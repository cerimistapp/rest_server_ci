
<?php

use Restserver\Libraries\REST_Controller;

defined('BASEPATH') or exit('No direct script access allowed');

// This can be removed if you use __autoload() in config.php OR use Modular Extensions
/** @noinspection PhpIncludeInspection */
require APPPATH . '/libraries/REST_Controller.php';

class Clip extends REST_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('clip_model', 'clip');
    }

    public function index_get()
    {
        $id = $this->get('id');
        if ($id === null) {
            $resources = $this->clip->getClip();
        } else {
            $resources = $this->clip->getClip($id);
        }
        if ($resources) {
            $this->response([
                'status' => true,
                'clip data' => $resources
            ], REST_Controller::HTTP_OK);
        } else {
            $this->response([
                'status' => false,
                'clip data' => 'id not found'
            ], REST_Controller::HTTP_NOT_FOUND);
        }
    }

    public function index_delete()
    {
        $id = $this->delete('id');

        if ($id === null) {
            $this->response([
                'status' => false,
                'message' => 'provide an id'
            ], REST_Controller::HTTP_BAD_REQUEST);
        } else {
            if ($this->clip->deleteClip($id) > 0) {
                $this->response([
                    'status' => true,
                    'id' => $id,
                    'message' => 'id was deleted'
                ], REST_Controller::HTTP_OK);
            } else {
                $this->response([
                    'status' => false,
                    'message' => 'id not found'
                ], REST_Controller::HTTP_BAD_REQUEST);
            }
        }
    }

    public function index_post()
    {
        $data = [
            'title' => $this->post('title'),
            'released' => $this->post('released'),
            'duration' => $this->post('duration'),
            'creator' => $this->post('creator'),
            'image_url' => $this->post('image_url'),
            'stream_url' => $this->post('stream_url'),
            'sinopsis' => $this->post('sinopsis')
        ];

        if ($this->clip->createClip($data) > 0) {
            $this->response([
                'status' => true,
                'message' => 'data has been added'
            ], REST_Controller::HTTP_CREATED);
        } else {
            $this->response([
                'status' => false,
                'message' => 'failed to add new data'
            ], REST_Controller::HTTP_BAD_REQUEST);
        }
    }

    public function index_put()
    {
        $id = $this->put('id');

        $data = [
            'title' => $this->put('title'),
            'released' => $this->put('released'),
            'duration' => $this->put('duration'),
            'creator' => $this->put('creator'),
            'image_url' => $this->put('image_url'),
            'stream_url' => $this->put('stream_url'),
            'sinopsis' => $this->put('sinopsis')
        ];

        if ($this->clip->updateClip($data, $id) > 0) {
            $this->response([
                'status' => true,
                'message' => 'data has been updated'
            ], REST_Controller::HTTP_OK);
        } else {
            $this->response([
                'status' => false,
                'message' => 'failed to update data'
            ], REST_Controller::HTTP_BAD_REQUEST);
        }
    }

    
}
