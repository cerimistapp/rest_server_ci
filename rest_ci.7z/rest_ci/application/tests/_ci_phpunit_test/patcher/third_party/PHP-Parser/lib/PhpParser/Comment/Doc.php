<?php

namespace PhpParser\Comment;

class Doc extends \PhpParser\Comment
{
}